
import subprocess
import socket
import sys
import whois




def get_ip_address(domain):
    try:
        ip = socket.gethostbyname(domain)
        return ip
    except Exception as e:
        return f"Error: {e}"


def run_command(command):
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
        return result.stdout.strip()
    except Exception as e:
        return f"Error: {e}"


def get_whois_info(domain):
    try:
        w = whois.whois(domain)
        # Format some key info for the report
        info = []
        for key in ["domain_name", "registrar", "creation_date", "expiration_date", "name_servers", "emails"]:
            value = w.get(key)
            if value:
                info.append(f"{key}: {value}")
        return "\n".join(info) if info else "No WHOIS info found."
    except Exception as e:
        return f"Error fetching WHOIS info: {e}"


def get_nslookup_info(domain):
    output = run_command(f"nslookup {domain}")
    if not output.strip():
        return "No output from nslookup. Is it installed and in your PATH?"
    return output


def get_nmap_info(target):
    nmap_path = r"C:\\Program Files (x86)\\Nmap\\nmap.exe"
    output = run_command(f'"{nmap_path}" -Pn -sV {target}')
    if not output.strip():
        return f"No output from nmap at {nmap_path}. Is it installed correctly?"
    return output


def main():
    target = input("Enter the target site (e.g., scanme.nmap.org): ").strip()
    # Remove protocol if present
    if target.startswith("http://"):
        target = target[len("http://"):]
    elif target.startswith("https://"):
        target = target[len("https://"):]
    # Remove trailing slash if present
    target = target.rstrip("/")
    print(f"Target: {target}\n{'='*40}")
    ip = get_ip_address(target)
    print(f"IP Address: {ip}\n")

    print("[+] Domain Registrar Info (whois):")
    whois_info = get_whois_info(target)
    print('\n'.join(whois_info.split('\n')[0:10]))  # Print first 10 lines for brevity
    print()

    print("[+] DNS Info (nslookup):")
    nslookup_info = get_nslookup_info(target)
    print(nslookup_info)
    print()

    print("[+] Nmap Scan (Open Ports & Services):")
    nmap_info = get_nmap_info(target)
    print(nmap_info)

    # Optionally, write a summary report
    with open("recon_report.txt", "w") as f:
        f.write(f"Target: {target}\n{'='*40}\n")
        f.write(f"IP Address: {ip}\n\n")
        f.write("[+] Domain Registrar Info (whois):\n")
        f.write(whois_info + "\n\n")
        f.write("[+] DNS Info (nslookup):\n")
        f.write(nslookup_info + "\n\n")
        f.write("[+] Nmap Scan (Open Ports & Services):\n")
        f.write(nmap_info + "\n")
    print("\nReport saved to recon_report.txt")


if __name__ == "__main__":
    main()
