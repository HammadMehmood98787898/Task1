#!/usr/bin/env python3
"""
Vulnerability Scanner GUI Application
Modern GUI interface for vulnerability scanning with Nmap
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import subprocess
import os
import sys
import platform
import re
import datetime
from pathlib import Path
import shutil
import threading
import xml.etree.ElementTree as ET

class VulnerabilityScannerGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Vulnerability Scanner Pro")
        self.root.geometry("800x700")
        self.root.configure(bg='#2b2b2b')
        
        # Initialize variables
        self.target_ip = tk.StringVar()
        self.nmap_path = tk.StringVar(value=self.find_nmap())
        self.save_report = tk.BooleanVar(value=True)
        self.scan_in_progress = False
        
        self.setup_gui()
        
    def setup_gui(self):
        """Setup the modern GUI interface"""
        # Title Frame
        title_frame = ttk.Frame(self.root)
        title_frame.pack(pady=20, padx=20, fill='x')
        
        title_label = ttk.Label(
            title_frame, 
            text="🔍 Vulnerability Scanner Pro", 
            font=('Arial', 16, 'bold'),
            foreground='#ffffff',
            background='#2b2b2b'
        )
        title_label.pack()
        
        subtitle_label = ttk.Label(
            title_frame,
            text="For educational and authorized testing only",
            font=('Arial', 10),
            foreground='#cccccc',
            background='#2b2b2b'
        )
        subtitle_label.pack(pady=(5, 0))
        
        # Main container
        main_container = ttk.Frame(self.root)
        main_container.pack(pady=10, padx=20, fill='both', expand=True)
        
        # Input Frame
        input_frame = ttk.LabelFrame(main_container, text="Scan Configuration", padding=15)
        input_frame.pack(fill='x', pady=(0, 15))
        
        # Target IP
        ttk.Label(input_frame, text="Target IP/Hostname:").grid(row=0, column=0, sticky='w', pady=5)
        target_entry = ttk.Entry(input_frame, textvariable=self.target_ip, width=30)
        target_entry.grid(row=0, column=1, padx=10, pady=5, sticky='ew')
        target_entry.focus()
        
        # Nmap Path
        ttk.Label(input_frame, text="Nmap Path:").grid(row=1, column=0, sticky='w', pady=5)
        nmap_frame = ttk.Frame(input_frame)
        nmap_frame.grid(row=1, column=1, padx=10, pady=5, sticky='ew')
        
        nmap_entry = ttk.Entry(nmap_frame, textvariable=self.nmap_path, width=40)
        nmap_entry.pack(side='left', fill='x', expand=True)
        
        ttk.Button(
            nmap_frame, 
            text="Browse", 
            command=self.browse_nmap,
            width=8
        ).pack(side='right', padx=(5, 0))
        
        # Options Frame
        options_frame = ttk.LabelFrame(main_container, text="Options", padding=15)
        options_frame.pack(fill='x', pady=(0, 15))
        
        ttk.Checkbutton(
            options_frame, 
            text="Save detailed report to file", 
            variable=self.save_report
        ).pack(anchor='w')
        
        ttk.Label(
            options_frame, 
            text="Note: Nikto requires Kali Linux for web vulnerability scanning",
            foreground='#ff6b6b',
            font=('Arial', 9)
        ).pack(anchor='w', pady=(10, 0))
        
        # Button Frame
        button_frame = ttk.Frame(main_container)
        button_frame.pack(fill='x', pady=10)
        
        self.scan_button = ttk.Button(
            button_frame,
            text="🚀 Start Vulnerability Scan",
            command=self.start_scan,
            style='Accent.TButton'
        )
        self.scan_button.pack(side='left', padx=(0, 10))
        
        ttk.Button(
            button_frame,
            text="🗑️ Clear Results",
            command=self.clear_results
        ).pack(side='left', padx=(0, 10))
        
        ttk.Button(
            button_frame,
            text="ℹ️ Help",
            command=self.show_help
        ).pack(side='left')
        
        # Progress Frame
        self.progress_frame = ttk.LabelFrame(main_container, text="Scan Progress", padding=15)
        self.progress_frame.pack(fill='x', pady=(0, 15))
        
        self.progress_bar = ttk.Progressbar(
            self.progress_frame, 
            mode='indeterminate'
        )
        self.progress_bar.pack(fill='x')
        
        self.status_label = ttk.Label(
            self.progress_frame,
            text="Ready to scan...",
            foreground='#00ff00'
        )
        self.status_label.pack(pady=(10, 0))
        
        # Results Frame
        results_frame = ttk.LabelFrame(main_container, text="Scan Results", padding=15)
        results_frame.pack(fill='both', expand=True)
        
        # Create text widget with scrollbar
        text_frame = ttk.Frame(results_frame)
        text_frame.pack(fill='both', expand=True)
        
        self.results_text = scrolledtext.ScrolledText(
            text_frame,
            wrap=tk.WORD,
            width=80,
            height=20,
            bg='#1e1e1e',
            fg='#ffffff',
            insertbackground='white',
            font=('Consolas', 10)
        )
        self.results_text.pack(fill='both', expand=True)
        
        # Configure styles
        self.configure_styles()
        
    def configure_styles(self):
        """Configure modern styles for the application"""
        style = ttk.Style()
        style.theme_use('clam')
        
        # Configure colors
        style.configure(
            'TLabel',
            background='#2b2b2b',
            foreground='#ffffff'
        )
        
        style.configure(
            'TLabelframe',
            background='#2b2b2b',
            foreground='#ffffff'
        )
        
        style.configure(
            'TLabelframe.Label',
            background='#2b2b2b',
            foreground='#ffffff'
        )
        
        style.configure(
            'TButton',
            background='#404040',
            foreground='#ffffff'
        )
        
        style.configure(
            'Accent.TButton',
            background='#007acc',
            foreground='#ffffff'
        )
        
    def find_nmap(self):
        """Find Nmap installation automatically"""
        nmap_paths = [
            r"C:\Program Files (x86)\Nmap\nmap.exe",
            r"C:\Program Files\Nmap\nmap.exe",
        ]
        
        for path in nmap_paths:
            if os.path.exists(path):
                return path
        
        if shutil.which("nmap"):
            return "nmap"
            
        return ""
    
    def browse_nmap(self):
        """Browse for Nmap executable"""
        filename = filedialog.askopenfilename(
            title="Select Nmap executable",
            filetypes=[("Executable files", "*.exe"), ("All files", "*.*")]
        )
        if filename:
            self.nmap_path.set(filename)
    
    def validate_target(self, target):
        """Validate target IP/hostname"""
        if not target:
            return False, "Target cannot be empty"
        
        # IP address pattern
        ip_pattern = r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$'
        if re.match(ip_pattern, target):
            octets = target.split('.')
            if all(0 <= int(octet) <= 255 for octet in octets):
                return True, "Valid IP address"
        
        # Hostname pattern
        hostname_pattern = r'^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)*$'
        if re.match(hostname_pattern, target):
            return True, "Valid hostname"
        
        return False, "Invalid target format"
    
    def update_status(self, message, color='#00ff00'):
        """Update status label"""
        self.status_label.config(text=message, foreground=color)
        self.root.update()
    
    def log_message(self, message, message_type='info'):
        """Add message to results text with coloring"""
        colors = {
            'info': '#ffffff',
            'success': '#00ff00',
            'warning': '#ffff00',
            'error': '#ff6b6b',
            'important': '#ffa500'
        }
        
        color = colors.get(message_type, '#ffffff')
        timestamp = datetime.datetime.now().strftime("%H:%M:%S")
        
        formatted_message = f"[{timestamp}] {message}\n"
        
        self.results_text.insert(tk.END, formatted_message)
        self.results_text.see(tk.END)
        self.root.update()
    
    def start_scan(self):
        """Start the vulnerability scan in a separate thread"""
        if self.scan_in_progress:
            return
        
        target = self.target_ip.get().strip()
        is_valid, message = self.validate_target(target)
        
        if not is_valid:
            messagebox.showerror("Invalid Target", message)
            return
        
        if not self.nmap_path.get() or not os.path.exists(self.nmap_path.get()):
            messagebox.showerror("Nmap Not Found", "Please provide a valid path to Nmap executable")
            return
        
        # Start scan in separate thread
        self.scan_in_progress = True
        self.scan_button.config(state='disabled')
        self.progress_bar.start()
        
        scan_thread = threading.Thread(target=self.run_scan, args=(target,))
        scan_thread.daemon = True
        scan_thread.start()
    
    def run_scan(self, target):
        """Run the vulnerability scan"""
        try:
            self.log_message(f"Starting vulnerability scan for target: {target}", 'important')
            self.update_status("Initializing scan...")
            
            # Create output directory
            output_dir = self.create_output_directory(target)
            
            # Run Nmap scan
            self.run_nmap_scan(target, output_dir)
            
            # Generate report
            if self.save_report.get():
                report_path = self.generate_report(target, output_dir)
                self.log_message(f"Detailed report saved: {report_path}", 'success')
            
            self.log_message("Vulnerability scan completed successfully!", 'success')
            self.update_status("Scan completed successfully!")
            
        except Exception as e:
            error_msg = f"Scan error: {str(e)}"
            self.log_message(error_msg, 'error')
            self.update_status("Scan failed!", '#ff0000')
            messagebox.showerror("Scan Error", error_msg)
        
        finally:
            self.scan_in_progress = False
            self.scan_button.config(state='normal')
            self.progress_bar.stop()
    
    def create_output_directory(self, target):
        """Create output directory for scan results"""
        clean_target = re.sub(r'[^a-zA-Z0-9\.\-]', '_', target)
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        output_dir = Path(f"scan_results_{clean_target}_{timestamp}")
        
        try:
            output_dir.mkdir(exist_ok=True)
            self.log_message(f"Created output directory: {output_dir}")
            return output_dir
        except Exception as e:
            self.log_message(f"Could not create output directory: {e}", 'warning')
            return Path(".")
    
    def run_nmap_scan(self, target, output_dir):
        """Run Nmap vulnerability scan"""
        self.update_status("Running Nmap vulnerability scan...")
        self.log_message("Starting Nmap vulnerability scan...", 'important')
        
        try:
            # Nmap command for vulnerability scanning
            nmap_command = [
                self.nmap_path.get(),
                "-sV",                    # Version detection
                "-sC",                    # Default scripts
                "--script", "vuln",       # Vulnerability scripts
                "-p", "80,443,22,21,23,25,53,110,135,139,143,993,995",  # Common ports
                "-T4",                    # Aggressive timing
                "--open",                 # Only show open ports
                "-oX", str(output_dir / "nmap_scan.xml"),
                "-oN", str(output_dir / "nmap_scan.txt"),
                target
            ]
            
            self.log_message(f"Executing: {' '.join(nmap_command)}")
            
            # Run Nmap
            result = subprocess.run(
                nmap_command,
                capture_output=True,
                text=True,
                timeout=600  # 10 minute timeout
            )
            
            if result.returncode == 0:
                self.log_message("Nmap scan completed successfully", 'success')
                self.parse_nmap_results(output_dir / "nmap_scan.xml")
            else:
                self.log_message(f"Nmap completed with warnings: {result.stderr}", 'warning')
                
        except subprocess.TimeoutExpired:
            self.log_message("Nmap scan timed out after 10 minutes", 'warning')
        except Exception as e:
            self.log_message(f"Nmap scan error: {str(e)}", 'error')
            raise
    
    def parse_nmap_results(self, xml_file):
        """Parse Nmap XML results and display findings"""
        self.update_status("Parsing scan results...")
        self.log_message("Parsing Nmap results...")
        
        try:
            if not os.path.exists(xml_file):
                self.log_message("Nmap XML output not found", 'warning')
                return
            
            tree = ET.parse(xml_file)
            root = tree.getroot()
            
            # Extract host information
            hosts = root.findall('host')
            if not hosts:
                self.log_message("No hosts found in scan results", 'warning')
                return
            
            for host in hosts:
                # Get host status
                status = host.find('status')
                if status is not None and status.get('state') == 'up':
                    # Get address
                    address_elem = host.find('address')
                    target_ip = address_elem.get('addr') if address_elem is not None else "Unknown"
                    
                    self.log_message(f"Target {target_ip} is up", 'success')
                    
                    # Get ports and services
                    ports = host.find('ports')
                    if ports is not None:
                        open_ports = []
                        for port in ports.findall('port'):
                            state = port.find('state')
                            if state is not None and state.get('state') == 'open':
                                port_id = port.get('portid')
                                protocol = port.get('protocol')
                                service = port.find('service')
                                service_name = service.get('name') if service is not None else "unknown"
                                product = service.get('product') if service is not None else ""
                                version = service.get('version') if service is not None else ""
                                
                                port_info = f"Port {port_id}/{protocol} - {service_name}"
                                if product:
                                    port_info += f" ({product} {version})"
                                
                                open_ports.append(port_info)
                                self.log_message(f"  🔓 {port_info}")
                        
                        self.log_message(f"Found {len(open_ports)} open ports", 'important')
                    
                    # Look for vulnerabilities in scripts
                    self.extract_vulnerabilities(host)
            
        except Exception as e:
            self.log_message(f"Error parsing Nmap results: {str(e)}", 'error')
    
    def extract_vulnerabilities(self, host):
        """Extract vulnerability information from Nmap scripts"""
        try:
            ports = host.find('ports')
            if ports is None:
                return
            
            vuln_count = 0
            for port in ports.findall('port'):
                scripts = port.find('script')
                if scripts is None:
                    continue
                
                for script in port.findall('script'):
                    script_id = script.get('id')
                    output = script.get('output', '')
                    
                    # Look for vulnerability indicators
                    if any(keyword in output.lower() for keyword in ['vulnerable', 'vulnerability', 'cve-', 'exploit', 'weak']):
                        vuln_count += 1
                        port_id = port.get('portid')
                        
                        self.log_message(f"  ⚠️  Potential vulnerability on port {port_id}:", 'warning')
                        self.log_message(f"     Script: {script_id}", 'warning')
                        
                        # Show first line of output
                        first_line = output.split('\n')[0]
                        if first_line:
                            self.log_message(f"     {first_line[:100]}...", 'warning')
            
            if vuln_count > 0:
                self.log_message(f"Found {vuln_count} potential vulnerabilities", 'important')
            else:
                self.log_message("No obvious vulnerabilities detected", 'success')
                
        except Exception as e:
            self.log_message(f"Error extracting vulnerabilities: {str(e)}", 'error')
    
    def generate_report(self, target, output_dir):
        """Generate a comprehensive text report"""
        self.update_status("Generating report...")
        
        report_file = output_dir / f"vulnerability_report_{target}.txt"
        
        try:
            with open(report_file, 'w', encoding='utf-8') as f:
                f.write("=" * 70 + "\n")
                f.write("VULNERABILITY ASSESSMENT REPORT\n")
                f.write("=" * 70 + "\n\n")
                
                f.write(f"Scan Information:\n")
                f.write(f"  Target: {target}\n")
                f.write(f"  Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"  Scanner: Vulnerability Scanner Pro v1.0\n")
                f.write(f"  Platform: {platform.system()} {platform.release()}\n\n")
                
                f.write("Executive Summary:\n")
                f.write("  This report contains results from automated vulnerability scanning.\n")
                f.write("  All findings should be verified manually before taking action.\n\n")
                
                f.write("Scan Methodology:\n")
                f.write("  - Nmap version detection (-sV)\n")
                f.write("  - Default script scanning (-sC)\n")
                f.write("  - Vulnerability script scanning (--script vuln)\n")
                f.write("  - Common service port scanning\n\n")
                
                f.write("Important Notes:\n")
                f.write("  - Only use this tool on systems you own or have permission to test\n")
                f.write("  - Automated tools may produce false positives/negatives\n")
                f.write("  - Always validate findings manually\n")
                f.write("  - Consider legal and ethical implications of security testing\n\n")
                
                f.write("Generated Files:\n")
                for file in output_dir.iterdir():
                    if file.is_file():
                        size_kb = file.stat().st_size / 1024
                        f.write(f"  - {file.name} ({size_kb:.1f} KB)\n")
                
                f.write("\n" + "=" * 70 + "\n")
                f.write("END OF REPORT\n")
                f.write("=" * 70 + "\n")
            
            self.log_message(f"Comprehensive report generated: {report_file}", 'success')
            return report_file
            
        except Exception as e:
            self.log_message(f"Error generating report: {str(e)}", 'error')
            return None
    
    def clear_results(self):
        """Clear the results text area"""
        self.results_text.delete(1.0, tk.END)
        self.update_status("Ready to scan...")
        self.log_message("Results cleared", 'info')
    
    def show_help(self):
        """Show help information"""
        help_text = """
Vulnerability Scanner Pro - Help Guide

🔍 Purpose:
- Automated vulnerability scanning for educational purposes
- Security assessment of authorized systems only

🎯 Usage:
1. Enter target IP address or hostname
2. Verify Nmap path (automatically detected)
3. Choose to save report (recommended)
4. Click 'Start Vulnerability Scan'

📊 Output:
- Real-time scan progress and results
- Open port detection
- Service version information
- Potential vulnerability identification
- Detailed text report (if enabled)

⚠️  Important:
- ONLY scan systems you own or have explicit permission to test
- Automated tools may have false positives/negatives
- Always verify findings manually
- Consider using Kali Linux for comprehensive web scanning (Nikto)

🔧 Requirements:
- Nmap must be installed on the system
- Administrator/root privileges may be required for some scans
        """
        
        help_window = tk.Toplevel(self.root)
        help_window.title("Help - Vulnerability Scanner Pro")
        help_window.geometry("600x500")
        help_window.configure(bg='#2b2b2b')
        
        help_text_widget = scrolledtext.ScrolledText(
            help_window,
            wrap=tk.WORD,
            bg='#1e1e1e',
            fg='#ffffff',
            font=('Arial', 10)
        )
        help_text_widget.pack(fill='both', expand=True, padx=20, pady=20)
        help_text_widget.insert(1.0, help_text)
        help_text_widget.config(state='disabled')

def main():
    """Main application entry point"""
    try:
        root = tk.Tk()
        app = VulnerabilityScannerGUI(root)
        root.mainloop()
    except Exception as e:
        print(f"Failed to start application: {e}")
        input("Press Enter to exit...")

if __name__ == "__main__":
    main()