# Task 3: Password Cracking (Dictionary Attack)

This mini-lab demonstrates cracking a simple MD5 password hash using a Python dictionary attack. It’s self-contained and doesn’t require any external packages.

## Files
- `sample_hash.txt` – Contains a single MD5 hash (of `password123`).
- `wordlist_small.txt` – A tiny wordlist with common passwords.
- `python_cracker.py` – A simple Python script that reads the hash and tries each word in the wordlist.

## How to run (Windows PowerShell)
- Make sure you have Python 3 on PATH.
- Run:
  - `python d:\Work\Task2\Task3_password_cracking\python_cracker.py`

Expected output:
- `CRACKED: 482c811da5d5b4bc6d497ffa98491e38 -> password123`

## How it works (briefly)
- Computes the MD5 digest for each candidate word from `wordlist_small.txt`.
- Compares it to the target hash from `sample_hash.txt`.
- Stops on the first match and prints the cracked password.

## Swap in your own data
- Replace the content of `sample_hash.txt` with a different MD5 hash (single line).
- Point to a different wordlist by editing the path in `python_cracker.py`, or replace the contents of `wordlist_small.txt`.

## Optional: Try with John the Ripper or Hashcat
If you’d like to try industry tools:

- Discover/install on Windows (use one of the package managers):
  - Winget (search first):
    - `winget search john`
    - `winget search hashcat`
    - Then install with the appropriate ID (e.g., `winget install <ID>`)
  - Chocolatey (search/install):
    - `choco search john`
    - `choco install john`
    - `choco search hashcat`
    - `choco install hashcat`

- Example usage once installed (adjust paths):
  - John (raw MD5):
    - `john --format=raw-md5 d:\Work\Task2\Task3_password_cracking\sample_hash.txt --wordlist=d:\Work\Task2\Task3_password_cracking\wordlist_small.txt`
  - Hashcat (raw MD5 = mode 0):
    - `hashcat -m 0 d:\Work\Task2\Task3_password_cracking\sample_hash.txt d:\Work\Task2\Task3_password_cracking\wordlist_small.txt`

Note: Use only with authorization and for educational purposes. Replace file paths as needed for your environment.
