import hashlib
from pathlib import Path

base = Path(__file__).resolve().parent
hash_file = base / 'sample_hash.txt'
wordlist_file = base / 'wordlist_small.txt'

def crack_md5(md5_hash, wordlist_path):
    with open(wordlist_path, 'r', encoding='utf-8', errors='ignore') as f:
        for word in f:
            pw = word.strip()  # remove newline
            if not pw:
                continue
            if hashlib.md5(pw.encode('utf-8')).hexdigest() == md5_hash:
                return pw
    return None

if __name__ == '__main__':
    md5_hash = hash_file.read_text(encoding='utf-8').strip()
    result = crack_md5(md5_hash, wordlist_file)
    if result:
        print(f"CRACKED: {md5_hash} -> {result}")
    else:
        print(f"NOT CRACKED: {md5_hash}")
